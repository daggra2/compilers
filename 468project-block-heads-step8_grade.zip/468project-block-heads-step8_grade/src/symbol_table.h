#ifndef __SYMBOL_TABLE_H
#define __SYMBOL_TABLE_H

#include<set>
#include<stdio.h>
#include<string>
#include <map>
#include <vector>
#include <iostream>
using namespace std;

class Symbol{
public:
	int type;
	std::string name;
	std::string value;
	Symbol(int t, std::string n, std::string v):type(t), name(n), value(v){}
	Symbol(int t, std::string n):type(t), name(n){}
	//symbol offset for the variables4
	int sym_offset;
};

class SymbolTable{
public:
	std::map<std::string, Symbol*> table;
	std::vector<Symbol*> ordered_table;
	SymbolTable* parent;
	std::vector<SymbolTable*> children;
	std::string scope;
	SymbolTable(std::string s, SymbolTable* p): scope(s), parent(p){}
	void InsertSymbol(Symbol* sym){
		if(table.find(sym->name) != table.end()){
			///print error
			///exit
			std::cout<<"DECLARATION ERROR"<<" "<<sym->name<<"\n";
			exit(1);
		}
		table.insert(std::make_pair(sym->name, sym));
		ordered_table.push_back(sym);
	}
	long long returnOffset(string var);
	long long returnLoclvars(string function_name);
	long long returnNonLoclvars(string function_name);
	std::vector<string> getGlobalVars();
	void PrintTables();
};


//AST
class AST {
public:
	//stupid variables
	std::string string_RHS;
  string token;
  Symbol* sym;
  AST* right;
  AST* left;

  // variables in class
  int token_type;
  string IO_type;
  string assignLHS;
  AST* assignRHS;

	//variable of condition node
	string comparison_operator;
	string ifbool_variable;
	AST* condition_RHS;
	AST* condition_LHS;

	//variable If-Statements
	string if_expression;
	vector<AST*> if_statement_list;
	AST* if_child;
	AST* if_parent;
	AST* else_part;
	//this type is for "IF" "ELSE" and "CALLER" and "RETURN"
	string type;

	//Call expression
	vector<AST*> callargs;
	string caller_name;

	//RETURN_type
	AST* return_expr;

  AST(string t, int input_toktype){
    token_type = input_toktype;
    token=t;
    sym = NULL;
    right = NULL;
    left = NULL;
    IO_type = "None";      //differ
    assignLHS = "\0";      //differ
    assignRHS = NULL;

		//assignement of condition node
		comparison_operator="\0";
		ifbool_variable="\0";
		condition_RHS=NULL;
		condition_LHS=NULL;

		//If If_Node
		if_expression="\0";
		if_child=NULL;
		if_parent=NULL;
		else_part=NULL;
		type="\0";             //to check if this is an expression or IF_node

		//call_expr
		// callargs = NULL;
		caller_name = "\0";

		//return expr
		return_expr = NULL;

  }
  AST(){}
  void PrintTree(AST* ast);
};

class VarRef: public AST{
public:
  VarRef(Symbol* a){
    AST::sym = a;
    AST::token = a->name;
		
    if(AST::sym->type == 270) //275
    {
			//Int
      AST::token_type = 2;
    }
    else if(AST::sym->type == 273) //278
    {
			//Float
      AST::token_type = 3;
    }
    else if(AST::sym->type == 272) //277
    {
			//String
      AST::token_type = 4;
    }

  }
};

class ArithNode:public AST{
public:

  ArithNode(std::string tok){
    AST::token = tok;
    AST::token_type = 1;
  }
};

class LiteralNode: public AST {
public:
  LiteralNode(string lit, int input_toktype){
    AST::token = lit;
    AST::token_type = input_toktype;
  }
};

class IONode : public AST {
public:

	//Constructor
	IONode(Symbol* sy, std::string input_iotype){
		if(sy != NULL){
			AST::sym = sy;
			AST::token = sy->name;
			AST::IO_type = input_iotype;
			if(sy->type == 270)
				AST::token_type = 2;//Int
			else if(sy->type == 273)
					AST::token_type = 3;//Float
			else if(sy->type == 272)
						AST::token_type = 4; //String
			else
						AST::token_type = 100; //crazy
		}
		else{
			AST::token = "newline";
			AST::IO_type = input_iotype;
			}
	}
};
class Print_Assembly{
	public:
		void print_assembly(std::vector<AST*>);
};
class AssignNode : public AST{
public:
	//Constructor
	AssignNode(std::string LHS, AST* RHS){
		AST::assignLHS = LHS;
		AST::assignRHS = RHS;

	}
	AssignNode(std::string LHS, string RHS){
		AST::assignLHS = LHS;
		AST::string_RHS = RHS;
	}

};

class register_allocation{
public:
  string register_name;
  string temporary_name;
  int dirty_flag;
  //constructor to set value to each register
  register_allocation(string reg){
    	register_name = reg;
    	temporary_name = "temporary";
    	dirty_flag = 0;
  }
};

class VectorTable{
public:
	VectorTable* vect_parent;
	std::vector <AST*> stmt_vect;
	std::vector<VectorTable *> vect_children;   //needs to understand
	//std::vector<AST*> final_vector;
	std::vector<class FunctionTable*> func_table;
	class SymbolTable* sym_table;
	void PrintTreeBig();
	void PrintTree(std::vector<AST*> final_vector);

	//Constructor
	VectorTable(VectorTable* parent): vect_parent(parent) {}

};

class FunctionTable{
public:
	string function_name;
	vector <AST*> func_vect;
};
//----------------------------------------------------------------STEP 5-------------------------------------------------------------------------
class ConditionNode: public AST{
public:
	// string comparison_operator;
	// string bool_variable;
	// AST* condition_RHS;
	// AST* condition_LHS;

	//default Constructor
	ConditionNode(AST* left, string comop, AST* right, string expression_type) {
		AST::condition_LHS = left;
		AST::condition_RHS = right;
		AST::comparison_operator = comop;
		AST::ifbool_variable = expression_type;
	}
};

class If_Node: public AST{
public:
	//ConditionNode* if_expression;
	//vector<AST*> if_statement_list;
	// If_Node* if_child;
	// If_Node* if_parent;
	// If_Node* else_part;
	// string type;

	//default constructor
	If_Node(AST* cond){
		AST::condition_RHS = cond->condition_RHS;
		AST::condition_LHS = cond->condition_LHS;
		AST::comparison_operator = cond->comparison_operator;
		AST::ifbool_variable = cond->ifbool_variable;
	}
	If_Node(){}

};

class while_Node: public AST{
public:
	while_Node(AST* cond){
		AST::condition_RHS = cond->condition_RHS;
		AST::condition_LHS = cond->condition_LHS;
		AST::comparison_operator = cond->comparison_operator;
		AST::ifbool_variable = cond->ifbool_variable;
	}
	while_Node(){}
};

//call expression node
class call_Node : public AST {
public:
		call_Node(std::vector<AST*> expression_values, std::string expression_call){
			AST::callargs = expression_values;
			AST::caller_name = expression_call;
			AST::type = "CALLER";
		}
};

class return_Node: public AST {
public:
		return_Node(AST* return_expression){
			AST::return_expr = return_expression;
			AST::type = "RETURN";
		}
};






// tania stuff
void compute_liveness();
void assign_predecessors();
void assign_successor_to_jump(string, int);
void print_IRNodeMap();
typedef class IRNode{
public:
	std::string instruction;	// this is the instruction
	std::string oper1;			// this is the first operator
	std::string oper2;			// this is the second operator (may be null for read or write or store)
	std::string result; 		// this is the temp where result will be stored
	int identity_num;
	vector<string> genSet;
	vector<string> killSet;
	vector<int> successors;
	vector<int> predecessors;
	set<string> LiveIn;
	set<string> LiveOut;
}IRNode;

typedef class CodeObj{
public:
	vector<IRNode> InstrSeq;	// the list of 3AC instructions
	std::string result;	// this is the temp where result is stored
	int type;		/* this is the type of the result of the instruction
							1->int var
							2->float var
							3->int literal
							4->float literal
					*/
}CodeObj;

// this will store all the IRcode for the whole program
typedef class IRCode{
public:
	std::vector<CodeObj*>complete_IR_code;
}IRCode;

CodeObj* return_RHS_3AC(AST* astNode, IRCode*);
CodeObj* return_LHS_3AC(std::string, CodeObj*);
void print_3AC_code(CodeObj*);
void print_IR_code(IRCode);
void convert_ir_to_assembly(IRCode ir_code);
void convert_3AC_code(CodeObj* currentCodeExpr);
CodeObj* return_write_3AC(AST* astnode);
CodeObj* return_read_3AC(AST* astnode);

void while_start_label(IRCode* ir_code);
void while_compare(AST* while_node, IRCode* ir_code);
void while_jump_end(IRCode* ir_code);
void while_jump_start(IRCode* ir_code);
void while_end_label(IRCode* ir_code);

void move_to_reg(CodeObj*, IRCode*);
std::string generateTemp();
void if_while_condition(AST*, IRCode*);
void print_label(IRCode*);
void endif_jump_statement(IRCode*);
void endif_label_statement(IRCode *);
string function_Call(AST* function_call, IRCode* ir_code, string);
void returnStmt(AST* return_node, IRCode* ir_code);
void deal_with_while(AST*, IRCode*);
//deepika's IR functions
IRNode return_register(vector <register_allocation*> reg_vector, IRNode n);
bool already_exists(string operator2, vector<register_allocation*> reg_vector);
bool present_in_liveout(string operator2, set<string> live_out);
string set_dirty(string operator2, int set_value , vector<register_allocation*> reg_vector);
string does_not_exists(string self, string oper1, string oper2, vector<register_allocation*> reg_vector, set<string> live_out);

#endif //__SYMBOL_TABLE_H
