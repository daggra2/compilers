
class register_allocation{
  string register_name;
  string temporary_name;
  int dirty_flag = 0;
  //constructor to set value to each register
  register_allocation(string register){
    register_name = register;
    value = "\0";
  }
}
//this function return the result register
//vectors contains pointer of register_allocation
string return_register(vector <register_allocation> reg_vector, IRNode n){
  std::string oper1 = n.oper1;
	std::string oper2 = n.oper2;
	std::string result = n.result;
  set<string> live_out = n.LiveOut;
  string new_opr1;
  string new_opr2;
  string new_result;
  //if oper1 is a temporary
  if(oper1.find("!T") == 0){
      bool exists = already_exists(oper1, reg_vector);
      bool in_liveout = present_in_liveout(oper1, reg_vector);

      if(exists){
        if(in_liveout){
          new_opr1 = set_dirty(oper1,1,reg_vector);
        }else{
          new_opr1 = set_dirty(oper1,0,reg_vector);
        }
      }else{
        new_opr1 = does_not_exists(oper1, oper2, result, reg_vector, live_out);
      }
  }
  //for operator 2
  if(oper2.find("!T") == 0){
      bool exists = already_exists(oper2, reg_vector);
      bool in_liveout = present_in_liveout(oper2, reg_vector);

      if(exists){
        if(in_liveout){
          new_opr2 = set_dirty(oper2,1,reg_vector);
        }else{
          new_opr2 = set_dirty(oper2,0,reg_vector);
        }
      }else{
        new_opr2 = does_not_exists(oper2, oper1, result, reg_vector, live_out);
      }
  }

  //for result
  if(result.find("!T") == 0){
      bool exists = already_exists(result, reg_vector);
      bool in_liveout = present_in_liveout(result, reg_vector);

      if(exists){
        if(in_liveout){
          new_result = set_dirty(result,1,reg_vector);
        }else{
          new_result = set_dirty(result,0,reg_vector);
        }
      }else{
        new_result = does_not_exists(result, oper1, oper2, reg_vector, live_out);
      }
  }



}



//check if the temporary already exists in any one of the 4 registers
bool already_exists(string operator, vector <register_allocation> reg_vector){
  for (int i=0; i< reg_vector.size(); i++){
    if(reg_vector[i]->temporary_name == operator){
      return true
    }
  }
  return false
}

//check if the temporary is in the live out set
bool present_in_liveout(string operator,set<string> live_out){
  if(live_out.find(operator) != live_out.end()){
    return true;
  }
  return false;
}

//setting dirty flag of the register and returing the registers
string set_dirty(string operator, int set_value ,vector <register_allocation> reg_vector){
  for (int i=0; i< reg_vector.size(); i++){
    if(reg_vector[i]->temporary_name == operator){
      reg_vector[i]->dirty_flag = set_value
      return reg_vector[i]->register_name
    }
  }
}


string does_not_exists(string self, string oper1, string oper2, vector <register_allocation> reg_vector, set<string> live_out){
  bool in_liveout = present_in_liveout(self, live_out)
  for(int i = 0; i < reg_vector.size(); i++){
    if(( reg_vector[i]->temporary_name != oper1 ) &&  ( reg_vector[i]->temporary_name != oper2 ) && (reg_vector[i]->dirty_flag == 0)){
      reg_vector[i]->temporary_name = self;
      if(in_liveout){
        reg_vector[i]->dirty_flag = 1;
        return reg_vector[i]->register_name
      }else{
        reg_vector[i]->dirty_flag = 0;
        return reg_vector[i]->register_name
      }
    }
  }
  //when they are all dirty what to do ---> it requires value---->how to write store instruction

}
