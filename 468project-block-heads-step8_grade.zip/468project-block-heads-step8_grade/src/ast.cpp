
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<string.h>
#include <map>
#include <vector>
#include <iostream>
#include "../generated/parser.hpp"

void AST::PrintTree(AST* ast) {
  if (ast == NULL)
    return;
  PrintTree(ast->left);
  std::cout<<endl;
  PrintTree(ast->right);
  std::cout<<endl;
  std::cout<<"Node is "<<ast->token<<std::endl;
}
