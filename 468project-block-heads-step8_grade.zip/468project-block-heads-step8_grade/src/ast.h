#ifndef __AST_H
#define __AST_H

#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<string.h>
#include <iostream>
#include "../generated/parser.hpp"
using namespace std;

class AST {
public:
  string token;
  Symbol* sym;
  AST* right;
  AST* left;
  // variables in class
  int token_type;
  string IO_type;
  string assignLHS;
  AST* assignRHS;

  AST(string t, int input_toktype){
    token_type = input_toktype;
    token=t;
    sym = NULL;
    right = NULL;
    left = NULL;
    IO_type = "None";      //differ
    assignLHS = nullptr;  //differ
    assignRHS = NULL;
  }
  AST(){}
  void PrintTree(AST* ast);
};

class VarRef: public AST{
public:
  VarRef(Symbol* a){
    AST::sym = a;
    AST::token = a->name;

    if(AST::sym->type == 275)
    {
      AST::token_type = 2;
    }
    else if(AST::sym->type == 278)
    {
      AST::token_type = 3;
    }
    else if(AST::sym->type == 277)
    {
      AST::token_type = 4;
    }

  }
};

class ArithNode:public AST{
public:

  ArithNode(std::string tok){
    AST::token = tok;
    AST::token_type = 1;
  }
};

class LiteralNode: public AST {
public:

  LiteralNode(string lit, int input_toktype){
    AST::token = lit;
    AST::token_type = input_toktype;
  }
};

class IONode : public AST {
public:

	//Constructor
	IONode(Symbol* sy, std::string input_iotype){
		if(sy != NULL){
			AST::sym = sy;
			AST::token = sy->name;
			AST::IO_type = input_iotype;
		}
		else{
			AST::token = "newline";
			AST::IO_type = input_iotype;
			}
	}
};

class AssignNode : public AST{
public:
	//Constructor
	AssignNode(std::string LHS, AST* RHS){
		AST::assignLHS = LHS;
		AST::assignRHS = RHS;

	}
};

class VectorTable{
public:
	VectorTable* vect_parent;
	std::vector <AST*> stmt_vect;
	std::vector<VectorTable *> vect_children;
	void PrintTree();

	//Constructor
	VectorTable(VectorTable* parent): vect_parent(parent) {}

};
#endif
