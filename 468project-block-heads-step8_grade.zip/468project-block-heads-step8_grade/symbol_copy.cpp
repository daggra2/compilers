#include<iostream>
#include <string>
#include <stack>
#include <vector>
#include <map>
#include <iterator>
#include <typeinfo>
#include "../src/symbol_table.h"
#include<cstdlib>
using namespace std;

std::map<string, string> store_map;
std::map<string, string>::iterator str_itr;

std::vector<register_allocation*> regVect;
long long int tempNum = 0; //From IR.cpp
std::vector<string> labels;
std::vector<string> end_if_labels;
std::vector<string> while_starts;
std::vector<string> while_ends;
long long int end_if_num = 0;
long long int label_num = 0;
long long int while_start = 0;
long long int while_end = 0;
string current_function = "\0";
SymbolTable * symbol_table;
int func_left_flag = 0;
int node_num = 0;
std::map<int, IRNode> IRid_IRNode;
int liveness_changed = 0;



class SymbolNode{
public:
	int offset;
	string varname;
	string scope;
};

std::vector<SymbolNode> symbols;

long long SymbolTable::returnOffset(string var_name){
	long long n;
	for(int i = 0; i < symbols.size(); i++){
		if(symbols[i].varname == var_name && symbols[i].scope == current_function){
			n = symbols[i].offset;
			return n;
		}
	}
	return 0;

}
long long SymbolTable::returnNonLoclvars(string function_name){

	long long num = 0;
	for(int i = 0; i < symbols.size(); i++){
		if(symbols[i].scope == function_name && symbols[i].offset > 0){
			num ++;
		}
	}
	return num;

}

long long SymbolTable::returnLoclvars(string function_name){

	long long num = 0;
	for (int i = 0; i < symbols.size(); i++){
		if(symbols[i].scope == function_name && symbols[i].offset < 0){
			num ++;
		}
	}
	return num;
}

void SymbolTable::PrintTables(){
	 for(int value =0; value < ordered_table.size() ; value++){
	 	//std::cout<<"name " << ordered_table[value]->name << " type "<<ordered_table[value]->type<<"\n";
		SymbolNode node;
	 	switch(ordered_table[value]->type){
	 		case 270: std::cout<<"var " << ordered_table[value]->name<<std::endl;
					node.offset = ordered_table[value]->sym_offset;
					node.varname = ordered_table[value]->name;
					node.scope = scope;
					symbols.push_back(node);
					break;
	 		case 273: std::cout<<"var " << ordered_table[value]->name<<std::endl;
					node.offset = ordered_table[value]->sym_offset;
					node.varname = ordered_table[value]->name;
					node.scope = scope;
					symbols.push_back(node);
					break;
	 		case 272: std::cout<<"str " << ordered_table[value]->name<<" "<<ordered_table[value]->value<<"\n"<<std::endl;
					node.offset = ordered_table[value]->sym_offset;
					node.varname = ordered_table[value]->name;
					node.scope = scope;
					symbols.push_back(node);
					break;
	 	}
	 }

	 if (!children.empty()){
	 	for(int child=0; child < children.size(); child++){
	 		(children[child])->PrintTables();
	 	}
	 }

}
/*
	----------------------- STEP 6 ----------------------------------
*/
void VectorTable :: PrintTreeBig(){

	symbol_table = sym_table;
	std::cout<<"push\npush\npush\npush\npush\n";
	std::cout<<"jsr main\nsys halt\n";
	for(int i = 0; i < func_table.size(); i++){
		node_num = 0;
		IRid_IRNode.clear();
		func_left_flag = 0;
		current_function = func_table[i]->function_name;
		std::cout<<"label "<<current_function<<std::endl;

		long long return_localnum = symbol_table->returnLoclvars(current_function);
		std::cout<<"link "<<std::to_string(return_localnum)<<std::endl;

		PrintTree(func_table[i]->func_vect);
	}
	return;
}

/*
	----------------------- END STEP 6 -------------------------------
*/
void deal_with_if(AST* ifNode, IRCode* ir_code){

	if(ifNode == NULL){
		return;
	}

	// if the node is IF, before inner stmts, print the comparison and the jump
	// if the node is ELSE, before inner stmts, print the label
	if(ifNode->type == "IF"){
		if_while_condition(ifNode, ir_code);
	}
	else{
		print_label(ir_code);
	}

	for(int i = 0 ; i < ifNode->if_statement_list.size(); i++){
		if(ifNode->if_statement_list[i]->type == "\0"){
			if(ifNode->if_statement_list[i]->IO_type == "WRITE"){
				CodeObj* write = return_write_3AC(ifNode->if_statement_list[i]);
				ir_code->complete_IR_code.push_back(write);
			}
			else if(ifNode->if_statement_list[i]->IO_type == "READ"){
				CodeObj* read = return_read_3AC(ifNode->if_statement_list[i]);
				ir_code->complete_IR_code.push_back(read);
			}
			else{
				if(ifNode->if_statement_list[i]->assignRHS->type == "CALLER"){
					function_Call(ifNode->if_statement_list[i]->assignRHS, ir_code, ifNode->if_statement_list[i]->assignLHS);
				}
				else{
					CodeObj* AC3_code_rhs = return_RHS_3AC(ifNode->if_statement_list[i]->assignRHS);
					ir_code->complete_IR_code.push_back(AC3_code_rhs);
					CodeObj* AC3_code_lhs = return_LHS_3AC(ifNode->if_statement_list[i]->assignLHS, AC3_code_rhs);
					ir_code->complete_IR_code.push_back(AC3_code_lhs);
				}
			}
		}
		else{
			if(ifNode->if_statement_list[i]->type == "RETURN"){
				returnStmt(ifNode->if_statement_list[i], ir_code);
			}
		}
	}

	deal_with_if(ifNode->if_child, ir_code);

	// if the node is IF jump to the END_IF
	// if the node is ELSE print the END_IF label
	if(ifNode->type == "IF"){
		endif_jump_statement(ir_code);
		if(ifNode->else_part == NULL){
			endif_label_statement(ir_code);
			print_label(ir_code);
		}
	}
	else{
		endif_label_statement(ir_code);
	}

	if(ifNode->else_part !=  NULL){
		deal_with_if(ifNode->else_part, ir_code);
	}

	return;
}

string create_endif_label(){
	string label = "endif_label" + std::to_string(end_if_num++);
	end_if_labels.push_back(label);

	return label;
}

/*
 * This function creates assembly for the endIf jumo statemnt
 */
void endif_jump_statement(IRCode* ir_code){
	CodeObj* endif = new CodeObj();
	IRNode endif_node;
	endif_node.identity_num = node_num;
	node_num ++;
	//endif_node.successors.push_back(endif_node.identity_num + 1);

	string end_if_label = create_endif_label();

	endif_node.instruction = "jmp";// + end_if_label;

	endif_node.oper1 = end_if_label;
	endif_node.oper2 = "\0";
	endif_node.result = "\0";
	IRid_IRNode.insert(pair<int, IRNode>(endif_node.identity_num, endif_node));

	endif->InstrSeq.push_back(endif_node);
	endif->result = "\0";
	endif->type = 0;

	ir_code->complete_IR_code.push_back(endif);

	return;

}

/*
 * This function creates the endIf label assembly line
 */
void endif_label_statement(IRCode* ir_code){
	CodeObj* label = new CodeObj();
	IRNode label_node;
	label_node.identity_num = node_num;
	node_num ++;
	label_node.successors.push_back(label_node.identity_num + 1);

	string some_label = end_if_labels.back();
	label_node.instruction = "label " + some_label;
	end_if_labels.pop_back();

	label_node.oper1 = "\0";
	label_node.oper2 = "\0";
	label_node.result = "\0";
	IRid_IRNode.insert(pair<int, IRNode>(label_node.identity_num, label_node));
	assign_successor_to_jump(some_label, label_node.identity_num);

	label->InstrSeq.push_back(label_node);
	label->result = "\0";
	label->type = 0;

	ir_code->complete_IR_code.push_back(label);

	return;

}

string get_comparison_string(string oper){
	// fill this out with opposite instr. Like if, oper is ">", return "le" (less than equal to)
	string ret_val;

	if(oper == ">"){
		ret_val = "le"; // i think this is le
	}
	else if(oper == ">="){
		ret_val = "lt";
	}
	else if(oper == "<"){
		ret_val = "ge";
	}
	else if(oper == "<="){
		ret_val = "gt";
	}
	else if(oper == "!="){
		ret_val = "eq";
	}
	else if(oper == "="){
		ret_val = "ne";
	}
	else{
		ret_val = "\0";
	}
	return ret_val;
}
string create_label(){
	string label = "label" + std::to_string(label_num);
	label_num++;
	labels.push_back(label);
	return label;
}

void print_label(IRCode* ir_code){
	CodeObj* label = new CodeObj();
	IRNode label_node;
	label_node.identity_num = node_num;
	label_node.successors.push_back(label_node.identity_num + 1);
	node_num ++;

	string some_label = labels.back();
	label_node.instruction = "label " + some_label;
	labels.pop_back();

	label_node.oper1 = "\0";
	label_node.oper2 = "\0";
	label_node.result = "\0";
	IRid_IRNode.insert(pair<int, IRNode>(label_node.identity_num, label_node));
	assign_successor_to_jump(some_label, label_node.identity_num);

	label->InstrSeq.push_back(label_node);
	label->result = "\0";
	label->type = 0;

	ir_code->complete_IR_code.push_back(label);

	return;
}
/*
 * This function creates assebly for the condition and the appropriate jump statement
 */
void if_while_condition(AST* if_while_node, IRCode* ir_code){
	long long return_off;
	string comp = get_comparison_string(if_while_node->comparison_operator); //**TODO**

	CodeObj* rhs = return_RHS_3AC(if_while_node->condition_RHS);
	ir_code->complete_IR_code.push_back(rhs);
	/*
	CodeObj* lhs = return_RHS_3AC(if_while_node->condition_LHS);
	ir_code->complete_IR_code.push_back(lhs);
*/
	CodeObj* compare = new CodeObj();
	CodeObj* jump = new CodeObj();
	IRNode ir_compare;

	IRNode ir_jump;

	string compare_start = "\0";
	switch(if_while_node->condition_LHS->token_type){
		case 2:
		case 5:
			compare_start = "cmpi ";	break;
		case 3:
		case 6:
			compare_start = "cmpr ";	break;
		default:
			compare_start = "cmpi ";
	}

	//move_to_reg(lhs, ir_code);
	//string left = ir_code->complete_IR_code.back()->result;
	move_to_reg(rhs, ir_code);
	string right = ir_code->complete_IR_code.back()->result;
	return_off = symbol_table->returnOffset(if_while_node->condition_LHS->token);

	string lhs = "$" + std::to_string(return_off);

	ir_compare.instruction = compare_start + lhs + " " + right;
	ir_compare.oper1 = "\0";
	ir_compare.oper2 = "\0";
	ir_compare.result = "\0";
	ir_compare.identity_num = node_num;
	ir_compare.genSet.push_back(lhs);		// TODO NOT SURE ABOUT THIS
	ir_compare.genSet.push_back(right);
	node_num ++;
	ir_compare.successors.push_back(ir_compare.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(ir_compare.identity_num, ir_compare));
	compare->InstrSeq.push_back(ir_compare);
	compare->result = "\0";
	compare->type = 0;

	string newLabel = create_label();
	ir_jump.instruction = "j" + comp; //+ " " + newLabel;
	ir_jump.oper1 = newLabel;
	ir_jump.oper2 = "\0";
	ir_jump.result = "\0";
	ir_jump.identity_num = node_num;
	ir_jump.successors.push_back(ir_jump.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(ir_jump.identity_num, ir_jump));
	node_num ++;

	jump->InstrSeq.push_back(ir_jump);
	jump->result = "\0";
	jump->type = 0;

	ir_code->complete_IR_code.push_back(compare);
	ir_code->complete_IR_code.push_back(jump);

	return;
}
void while_start_label(IRCode* ir_code){
	CodeObj* object = new CodeObj();
	IRNode node;

	string label = "while_start" + std::to_string(while_start++);
	node.instruction = "label";
	while_starts.push_back(label);
	node.oper1 = label;
	node.oper2 = "\0";
	node.result = "\0";
	node.identity_num = node_num;
	node.successors.push_back(node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node.identity_num, node));
	node_num ++;
	//assign_successor_to_jump(label, node.identity_num);

	object->InstrSeq.push_back(node);
	object->result = "\0";
	object->type = 0;

	ir_code->complete_IR_code.push_back(object);
}
void move_to_reg(CodeObj* codeObj, IRCode* ir_code){
	CodeObj* newCode = new CodeObj();
	IRNode node;
	string temp = generateTemp();

	node.instruction = "move " + codeObj->result + " " + temp;
	node.oper1 = codeObj->result;
	node.oper2 = "\0";
	node.result = temp;
	node.identity_num = node_num;
	node.genSet.push_back(codeObj->result);	// TODO NOT SURE
	node.killSet.push_back(temp);
	node.successors.push_back(node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node.identity_num, node));
	node_num ++;

	newCode->InstrSeq.push_back(node);
	newCode->result = temp;
	newCode->type = 0;

	ir_code->complete_IR_code.push_back(newCode);

}

void while_compare(AST* while_node, IRCode* ir_code){
	string comp = get_comparison_string(while_node->comparison_operator);

	CodeObj* rhs = return_RHS_3AC(while_node->condition_RHS);
	ir_code->complete_IR_code.push_back(rhs);
/*
	CodeObj* lhs = return_RHS_3AC(while_node->condition_LHS);
	ir_code->complete_IR_code.push_back(lhs);
*/
	CodeObj* compare = new CodeObj();
	IRNode ir_compare;

	string compare_start = "\0";
	switch(while_node->condition_LHS->token_type){
		case 2:
		case 5:
			compare_start = "cmpi ";	break;
		case 3:
		case 6:
			compare_start = "cmpr ";	break;
		default:
			compare_start = "cmpi ";
	}

	//move_to_reg(lhs, ir_code);
//	string left = ir_code->complete_IR_code.back()->result;
	move_to_reg(rhs, ir_code);
	string right = ir_code->complete_IR_code.back()->result;
	long long return_off = symbol_table->returnOffset(while_node->condition_LHS->token);

	string lhs = "$" + std::to_string(return_off);

	ir_compare.instruction = compare_start + lhs + " " + right;
	ir_compare.oper1 = "\0";
	ir_compare.oper2 = "\0";
	ir_compare.result = "\0";
	ir_compare.identity_num = node_num;
	ir_compare.genSet.push_back(lhs);	// TODO NOT SURE
	ir_compare.genSet.push_back(right);
	ir_compare.successors.push_back(ir_compare.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(ir_compare.identity_num, ir_compare));
	node_num ++;

	compare->InstrSeq.push_back(ir_compare);
	compare->result = "\0";
	compare->type = 0;

	ir_code->complete_IR_code.push_back(compare);

}

void while_jump_end(IRCode* ir_code, AST* while_node){
	CodeObj* object = new CodeObj();
	IRNode node;

	string comp = get_comparison_string(while_node->comparison_operator); //**TODO**

	string label = "while_end" + std::to_string(while_end++);
	node.instruction = "j" + comp; // + " " + label;
	while_ends.push_back(label);
	node.oper1 = label;
	node.oper2 = "\0";
	node.result = "\0";
	node.identity_num = node_num;
	node.successors.push_back(node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node.identity_num, node));
	node_num ++;

	object->InstrSeq.push_back(node);
	object->result = "\0";
	object->type = 0;

	ir_code->complete_IR_code.push_back(object);

}
void while_jump_start(IRCode* ir_code){
	CodeObj* object = new CodeObj();
	IRNode node;

	string label = while_starts.back();
	while_starts.pop_back();
	node.instruction = "jmp";// + label;
	node.oper1 = label;
	node.oper2 = "\0";
	node.result = "\0";
	node.identity_num = node_num;
	//node.successors.push_back(node.identity_num + 1);
	node_num ++;
	for(int i = 0; i < node_num; i++){
		if(IRid_IRNode[i].oper1 == label){
			cout<<"\nFOUND IT: "<<IRid_IRNode[i].oper1<<endl;
			IRid_IRNode[node.identity_num].successors.push_back(i);
		}
	}

	IRid_IRNode.insert(pair<int, IRNode>(node.identity_num, node));
	object->InstrSeq.push_back(node);
	object->result = "\0";
	object->type = 0;

	ir_code->complete_IR_code.push_back(object);

}

void assign_successor_to_jump(string label_target, int succ_num){
	for(int i = 0; i < node_num; i++){
		if(IRid_IRNode[i].oper1 == label_target){
			IRid_IRNode[i].successors.push_back(succ_num);
		}
	}
}

void while_end_label(IRCode* ir_code){
	CodeObj* object = new CodeObj();
	IRNode node;

	string label = while_ends.back();
	while_ends.pop_back();
	node.instruction = "label " + label;
	node.oper1 = "\0";
	node.oper2 = "\0";
	node.result = "\0";
	node.identity_num = node_num;
	node.successors.push_back(node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node.identity_num, node));
	node_num ++;
	// look through nodemap to find predecessor
	assign_successor_to_jump(label, node.identity_num);

	object->InstrSeq.push_back(node);
	object->result = "\0";
	object->type = 0;

	ir_code->complete_IR_code.push_back(object);

}

void deal_with_while(AST* while_node, IRCode* ir_code){
	while_start_label(ir_code);
	while_compare(while_node, ir_code);
	while_jump_end(ir_code, while_node);
	for (int j = 0; j < while_node->if_statement_list.size(); j++){
		if(while_node->if_statement_list[j]->type != "\0"){
			if(while_node->if_statement_list[j]->type == "IF"){
				deal_with_if(while_node->if_statement_list[j], ir_code);
			}
			else if(while_node->if_statement_list[j]->type == "RETURN"){
				returnStmt(while_node->if_statement_list[j], ir_code);
			}
		}
		else{
			if(while_node->if_statement_list[j]->IO_type == "WRITE"){
				CodeObj* write = return_write_3AC(while_node->if_statement_list[j]);
				ir_code->complete_IR_code.push_back(write);
			}
			else if(while_node->if_statement_list[j]->IO_type == "READ"){
				CodeObj* read = return_read_3AC(while_node->if_statement_list[j]);
				ir_code->complete_IR_code.push_back(read);
			}
			else{
				if(while_node->if_statement_list[j]->assignRHS->type == "CALLER"){
					function_Call(while_node->if_statement_list[j]->assignRHS, ir_code, while_node->if_statement_list[j]->assignLHS);
				}
				else{
					CodeObj* AC3_code_rhs = return_RHS_3AC(while_node->if_statement_list[j]->assignRHS);
					ir_code->complete_IR_code.push_back(AC3_code_rhs);
					CodeObj* AC3_code_lhs = return_LHS_3AC(while_node->if_statement_list[j]->assignLHS, AC3_code_rhs);
					ir_code->complete_IR_code.push_back(AC3_code_lhs);
				}
			}
		}
	}

	while_jump_start(ir_code);
	while_end_label(ir_code);
}
std::vector<string> push_function_args(AST* function_call, IRCode* ir_code){
	int ct = 0;
	std::vector<string> arg_registers;
	for(int i = 0; i < function_call->callargs.size(); i++){
		ct++;
		CodeObj* code_obj = return_RHS_3AC(function_call->callargs[i]);
		ir_code->complete_IR_code.push_back(code_obj);
		//std::cout<<"\nfunction: "<<function_call->caller_name<<" arg: "<<function_call->callargs[i]<<" result stored in: "<<code_obj->result;
		arg_registers.push_back(code_obj->result);
	}

	return arg_registers;
}
void function_Call(AST* function_call, IRCode* ir_code, string lhs){
	CodeObj* push_regs = new CodeObj();
	CodeObj* push_args = new CodeObj();
	CodeObj* jsr = new CodeObj();
	CodeObj* pop_regs = new CodeObj();
	CodeObj* pop_args = new CodeObj();
	CodeObj* retVal_to_lhs = new CodeObj();

	IRNode node_push_regs0;
	IRNode node_push_regs1;
	IRNode node_push_regs2;
	IRNode node_push_regs3;
	IRNode node_push_regs4;
	IRNode node_jsr;
	IRNode node_pop_regs0;
	IRNode node_pop_regs1;
	IRNode node_pop_regs2;
	IRNode node_pop_regs3;
	IRNode node_retVal_to_lhs;

	string function_name = function_call->caller_name;
	std::vector<string> arg_registers = push_function_args(function_call, ir_code);

	// push regs
	node_push_regs0.instruction = "push";
	node_push_regs0.oper1 = "\0";
	node_push_regs0.oper2 = "\0";
	node_push_regs0.result = "\0";
	node_push_regs0.identity_num = node_num;
	node_num ++;
	node_push_regs0.successors.push_back(node_push_regs0.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_push_regs0.identity_num, node_push_regs0));

	push_regs->InstrSeq.push_back(node_push_regs0);
	push_regs->result = "\0";
	push_regs->type = 0;

	node_push_regs1.instruction = "push r0";
	node_push_regs1.oper1 = "\0";
	node_push_regs1.oper2 = "\0";
	node_push_regs1.result = "\0";
	node_push_regs1.identity_num = node_num;
	node_push_regs1.genSet.push_back("r0");
	node_num ++;
	node_push_regs1.successors.push_back(node_push_regs1.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_push_regs1.identity_num, node_push_regs1));

	push_regs->InstrSeq.push_back(node_push_regs1);
	push_regs->result = "\0";
	push_regs->type = 0;

	node_push_regs2.instruction = "push r1";
	node_push_regs2.oper1 = "\0";
	node_push_regs2.oper2 = "\0";
	node_push_regs2.result = "\0";
	node_push_regs2.identity_num = node_num;
	node_push_regs2.genSet.push_back("r1");
	node_num ++;
	node_push_regs2.successors.push_back(node_push_regs2.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_push_regs2.identity_num, node_push_regs2));

	push_regs->InstrSeq.push_back(node_push_regs2);
	push_regs->result = "\0";
	push_regs->type = 0;

	node_push_regs3.instruction = "push r2";
	node_push_regs3.oper1 = "\0";
	node_push_regs3.oper2 = "\0";
	node_push_regs3.result = "\0";
	node_push_regs3.identity_num = node_num;
	node_push_regs3.genSet.push_back("r2");
	node_num ++;
	node_push_regs3.successors.push_back(node_push_regs3.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_push_regs3.identity_num, node_push_regs3));

	push_regs->InstrSeq.push_back(node_push_regs3);
	push_regs->result = "\0";
	push_regs->type = 0;

	node_push_regs4.instruction = "push r3";
	node_push_regs4.oper1 = "\0";
	node_push_regs4.oper2 = "\0";
	node_push_regs4.result = "\0";
	node_push_regs4.identity_num = node_num;
	node_push_regs4.genSet.push_back("r3");
	node_num ++;
	node_push_regs4.successors.push_back(node_push_regs4.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_push_regs4.identity_num, node_push_regs4));

	push_regs->InstrSeq.push_back(node_push_regs4);
	push_regs->result = "\0";
	push_regs->type = 0;

	ir_code->complete_IR_code.push_back(push_regs);

	// push args
	string temp;
	string pop_temp;
	for (int i = 0; i < arg_registers.size(); i++){
		IRNode node_push_args;
		node_push_args.instruction = "push " + arg_registers[i];
		node_push_args.oper1 = "\0";
		node_push_args.oper2 = "\0";
		node_push_args.result = "\0";
		node_push_args.identity_num = node_num;
		node_push_args.genSet.push_back(arg_registers[i]);
		node_num ++;
		node_push_args.successors.push_back(node_push_args.identity_num + 1);
		IRid_IRNode.insert(pair<int, IRNode>(node_push_args.identity_num, node_push_args));

		push_args->InstrSeq.push_back(node_push_args);
		push_args->result = "\0";
		push_args->type = 0;

		temp = temp + "\npush " + arg_registers[i];
		pop_temp = pop_temp + "\npop";
	}
	ir_code->complete_IR_code.push_back(push_args);

	// jsr
	node_jsr.instruction = "jsr " + function_name;
	node_jsr.oper1 = "\0";
	node_jsr.oper2 = "\0";
	node_jsr.result = "\0";
	node_jsr.identity_num = node_num;
	node_jsr.successors.push_back(node_jsr.identity_num + 1);
	// TODO wite a fnc that gets all global variables
	node_jsr.genSet.push_back("all global variables");
	node_num ++;
	IRid_IRNode.insert(pair<int, IRNode>(node_jsr.identity_num, node_jsr));

	jsr->InstrSeq.push_back(node_jsr);
	jsr->result = "\0";
	jsr->type = 0;

	ir_code->complete_IR_code.push_back(jsr);

	// pop args
	//
	for (int i = 0; i < arg_registers.size(); i++){
		IRNode node_pop_args;
		node_pop_args.instruction = "pop";
		node_pop_args.oper1 = "\0";
		node_pop_args.oper2 = "\0";
		node_pop_args.result = "\0";
		node_pop_args.identity_num = node_num;
		node_pop_args.killSet.push_back(arg_registers[i]);
		node_num ++;
		node_pop_args.successors.push_back(node_pop_args.identity_num + 1);
		IRid_IRNode.insert(pair<int, IRNode>(node_pop_args.identity_num, node_pop_args));

		pop_args->InstrSeq.push_back(node_pop_args);
		pop_args->result = "\0";
		pop_args->type = 0;
	}

	ir_code->complete_IR_code.push_back(pop_args);

	// pop regs
	node_pop_regs0.instruction = "pop r3";
	node_pop_regs0.oper1 = "\0";
	node_pop_regs0.oper2 = "\0";
	node_pop_regs0.result = "\0";
	node_pop_regs0.identity_num = node_num;
	node_pop_regs0.killSet.push_back("r3");
	node_num ++;
	node_pop_regs0.successors.push_back(node_pop_regs0.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_pop_regs0.identity_num, node_pop_regs0));

	pop_regs->InstrSeq.push_back(node_pop_regs0);
	pop_regs->result = "\0";
	pop_regs->type = 0;

	node_pop_regs1.instruction = "pop r2";
	node_pop_regs1.oper1 = "\0";
	node_pop_regs1.oper2 = "\0";
	node_pop_regs1.result = "\0";
	node_pop_regs1.identity_num = node_num;
	node_pop_regs1.killSet.push_back("r2");
	node_num ++;
	node_pop_regs1.successors.push_back(node_pop_regs1.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_pop_regs1.identity_num, node_pop_regs1));

	pop_regs->InstrSeq.push_back(node_pop_regs1);
	pop_regs->result = "\0";
	pop_regs->type = 0;

	node_pop_regs2.instruction = "pop r1";
	node_pop_regs2.oper1 = "\0";
	node_pop_regs2.oper2 = "\0";
	node_pop_regs2.result = "\0";
	node_pop_regs2.identity_num = node_num;
	node_pop_regs2.killSet.push_back("r1");
	node_num ++;
	node_pop_regs2.successors.push_back(node_pop_regs2.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_pop_regs2.identity_num, node_pop_regs2));

	pop_regs->InstrSeq.push_back(node_pop_regs2);
	pop_regs->result = "\0";
	pop_regs->type = 0;

	node_pop_regs3.instruction = "pop r0";
	node_pop_regs3.oper1 = "\0";
	node_pop_regs3.oper2 = "\0";
	node_pop_regs3.result = "\0";
	node_pop_regs3.identity_num = node_num;
	node_pop_regs3.killSet.push_back("r0");
	node_num ++;
	node_pop_regs3.successors.push_back(node_pop_regs3.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_pop_regs3.identity_num, node_pop_regs3));

	pop_regs->InstrSeq.push_back(node_pop_regs3);
	pop_regs->result = "\0";
	pop_regs->type = 0;

	ir_code->complete_IR_code.push_back(pop_regs);

	// pop return value
	long long return_off = symbol_table->returnOffset(lhs);
	string lhsss = "$" + std::to_string(return_off); 	// TODO function call

	node_retVal_to_lhs.instruction = "pop r0";
	node_retVal_to_lhs.oper1 = "\0";
	node_retVal_to_lhs.oper2 = "\0";
	node_retVal_to_lhs.result = "\0";
	node_retVal_to_lhs.identity_num = node_num;
	node_retVal_to_lhs.killSet.push_back("r0");
	node_retVal_to_lhs.successors.push_back(node_retVal_to_lhs.identity_num + 1);
	node_num ++;
	IRid_IRNode.insert(pair<int, IRNode>(node_retVal_to_lhs.identity_num, node_retVal_to_lhs));

	retVal_to_lhs->InstrSeq.push_back(node_retVal_to_lhs);
	retVal_to_lhs->result = "\0";
	retVal_to_lhs->type = 0;

	IRNode node_retVal_mov;
	node_retVal_mov.instruction = "move r0 " + lhsss;
	node_retVal_mov.oper1 = "\0";
	node_retVal_mov.oper2 = "\0";
	node_retVal_mov.result = "\0";
	node_retVal_mov.identity_num = node_num;
	node_retVal_mov.genSet.push_back("r0");	// TODO NOT SURE
	node_retVal_mov.killSet.push_back(lhsss);
	node_num ++;
	node_retVal_mov.successors.push_back(node_retVal_mov.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node_retVal_mov.identity_num, node_retVal_mov));

	retVal_to_lhs->InstrSeq.push_back(node_retVal_mov);
	retVal_to_lhs->result = "\0";
	retVal_to_lhs->type = 0;

	ir_code->complete_IR_code.push_back(retVal_to_lhs);

	return;
}

void VectorTable::PrintTree(std::vector<AST*> final_vector){
	//creating the 4 registers
	register_allocation* r0 = new register_allocation("!R0");
	register_allocation* r1 = new register_allocation("!R1");
	register_allocation* r2 = new register_allocation("!R2");
	register_allocation* r3 = new register_allocation("!R3");

	regVect.push_back(r0);
	regVect.push_back(r1);
	regVect.push_back(r2);
	regVect.push_back(r3);

	IRCode ir_code;
	for (int i = 0 ; i < final_vector.size(); i++){
		if(final_vector[i]->type != "\0"){				// then it is either while or if
			if(final_vector[i]->type == "WHILE"){
				deal_with_while(final_vector[i], &ir_code);
			}
			else if(final_vector[i]->type == "RETURN"){
				returnStmt(final_vector[i], &ir_code);
			}
			else{
				deal_with_if(final_vector[i], &ir_code);
			}
		}
		else{
			if(final_vector[i]->IO_type == "WRITE"){
				CodeObj* write = return_write_3AC(final_vector[i]);
				ir_code.complete_IR_code.push_back(write);
			}
			else if(final_vector[i]->IO_type == "READ"){
				CodeObj* read = return_read_3AC(final_vector[i]);
				ir_code.complete_IR_code.push_back(read);
			}
			else{
				if(final_vector[i]->assignRHS->type == "CALLER"){
					function_Call(final_vector[i]->assignRHS, &ir_code, final_vector[i]->assignLHS);
				}
				else{
					CodeObj* AC3_code_rhs = return_RHS_3AC(final_vector[i]->assignRHS);
					ir_code.complete_IR_code.push_back(AC3_code_rhs);
					CodeObj* AC3_code_lhs = return_LHS_3AC(final_vector[i]->assignLHS, AC3_code_rhs);
					ir_code.complete_IR_code.push_back(AC3_code_lhs);
				}
			}
		}
	}
	CodeObj* finish = new CodeObj();
	IRNode ret_node;
	IRNode unlnk_node;

	unlnk_node.instruction = "unlnk";
	unlnk_node.oper1 = "\0";
	unlnk_node.oper2 = "\0";
	unlnk_node.result = "\0";
	unlnk_node.identity_num = node_num;
	node_num ++;
	unlnk_node.successors.push_back(unlnk_node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(unlnk_node.identity_num, unlnk_node));

	finish->InstrSeq.push_back(unlnk_node);
	finish->result = "\0";
	finish->type = 0;

	ret_node.instruction = "ret";
	ret_node.oper1 = "\0";
	ret_node.oper2 = "\0";
	ret_node.result = "\0";
	ret_node.identity_num = node_num;
	node_num ++;
	ret_node.successors.push_back(ret_node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(ret_node.identity_num, ret_node));

	finish->InstrSeq.push_back(ret_node);
	finish->result = "\0";
	finish->type = 0;

	ir_code.complete_IR_code.push_back(finish);

	assign_predecessors();

	do{
		compute_liveness();
	}while(liveness_changed);	// compute liveness as long as there were some changes

	print_IRNodeMap(); // JUST FOR DEBUGGING PURPOSES UNIMPORTANT FUNCTION
	print_IR_code(ir_code);	// JUST FOR DEBUGGING
	convert_ir_to_assembly(ir_code);
	return;

}

void compute_liveness(){
	liveness_changed = 0;
	for(int i = node_num - 2; i >= 0; i--){
		set<string> livein_before = IRid_IRNode[i].LiveIn;
		set<string> liveout_before = IRid_IRNode[i].LiveOut;
		// live out
		for(int j = 0; j < IRid_IRNode[i].successors.size(); j ++){
			set<string> mySet = IRid_IRNode[IRid_IRNode[i].successors[j]].LiveIn;
			for(set<string>::iterator it = mySet.begin(); it != mySet.end(); it++){
				IRid_IRNode[i].LiveOut.insert(*it);
			}
		}
		// live in
		set<string> myLO = IRid_IRNode[i].LiveOut;	// add liveout
		for(set<string>::iterator it = myLO.begin(); it != myLO.end(); it++){
			IRid_IRNode[i].LiveIn.insert(*it);
		}
		for(int j = 0; j < IRid_IRNode[i].killSet.size(); j++){	// minus killset
			IRid_IRNode[i].LiveIn.erase(IRid_IRNode[i].killSet[j]);
		}
		for(int j = 0; j < IRid_IRNode[i].genSet.size(); j++){	// plus genSet
			IRid_IRNode[i].LiveIn.insert(IRid_IRNode[i].genSet[j]);
		}

		if(livein_before != IRid_IRNode[i].LiveIn || liveout_before != IRid_IRNode[i].LiveOut){
			liveness_changed = 1;
		}
	}
}

void assign_predecessors(){
	for(int i = node_num - 1; i >= 0; i--){
		for(int j = 0; j < IRid_IRNode[i].successors.size(); j++){
			IRid_IRNode[IRid_IRNode[i].successors[j]].predecessors.push_back(i);
		}
	}
}

void returnStmt(AST* return_node, IRCode* ir_code){
	// do the needsful for RHS
	// store in appropriate place
	func_left_flag ++;
	CodeObj* ret = new CodeObj();
	IRNode node;

	CodeObj* ret_calc = return_RHS_3AC(return_node->return_expr);
	ir_code->complete_IR_code.push_back(ret_calc);
	string result = ret_calc->result;

	long long return_nonlocalnum = symbol_table->returnNonLoclvars(current_function);

	string s = "$" + std::to_string(6 + return_nonlocalnum);
	node.instruction = "move " + result + " " + s; //std::to_string(6 + return_nonlocalnum);
	node.oper1 = result;
	node.oper2 = "\0";
	node.result = s;

	node.identity_num = node_num;
	node.genSet.push_back(result);
	node.killSet.push_back(s);
	node_num ++;
	node.successors.push_back(node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(node.identity_num, node));

	ret->InstrSeq.push_back(node);
	ret->result = "\0";
	ret->type = 0;

	ir_code->complete_IR_code.push_back(ret);

	CodeObj* unlnk = new CodeObj();
	IRNode unlnk_node;
	IRNode ret_node;

	unlnk_node.instruction = "unlnk";
	unlnk_node.oper1 = "\0";
	unlnk_node.oper2 = "\0";
	unlnk_node.result = "\0";
	unlnk_node.identity_num = node_num;
	node_num ++;
	unlnk_node.successors.push_back(unlnk_node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(unlnk_node.identity_num, unlnk_node));

	unlnk->InstrSeq.push_back(unlnk_node);
	unlnk->result = "\0";
	unlnk->type = 0;

	ret_node.instruction = "ret";
	ret_node.oper1 = "\0";
	ret_node.oper2 = "\0";
	ret_node.result = "\0";
	ret_node.identity_num = node_num;
	node_num ++;
	ret_node.successors.push_back(ret_node.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(ret_node.identity_num, ret_node));

	unlnk->InstrSeq.push_back(ret_node);
	unlnk->result = "\0";
	unlnk->type = 0;

	ir_code->complete_IR_code.push_back(unlnk);


	//return_localnum = 0;
	//symbol_table->returnLoclvars(current_function);
	//std::cout<<"\nfunction: "<<current_function<<" args: "<<return_nonlocalnum;
	//std::cout<<"\nfunction: "<<current_function<<" local vars: "<<return_localnum;
	return;
}

CodeObj* return_read_3AC(AST* astnode){

	CodeObj* newObj = new CodeObj();
	IRNode newnode;

	switch(astnode->token_type){
		case 2:
		case 5:
			newnode.instruction = ";READI";
			break;
		case 3:
		case 6:
			newnode.instruction = ";READF";
			break;
	}
	long long return_off = symbol_table->returnOffset(astnode->token);

	newnode.oper1 = "$" + std::to_string(return_off);
	newnode.oper2 = "\0";
	newnode.result = "\0";
	newnode.identity_num = node_num;
	newnode.killSet.push_back(std::to_string(return_off));
	node_num ++;
	newnode.successors.push_back(newnode.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(newnode.identity_num, newnode));

	newObj->InstrSeq.push_back(newnode);
	newObj->result = "\0";
	newObj->type = astnode->token_type;

	return newObj;
}

CodeObj* return_write_3AC(AST* astnode){

	CodeObj* newObj = new CodeObj();
	IRNode newnode;
	string tok;
	long long return_off;

	switch(astnode->token_type){
		case 4:
			tok = astnode->token;
			newnode.instruction = ";WRITES";
			break;
		case 2:
		case 5:
			return_off = symbol_table->returnOffset(astnode->token);
			tok = "$" + std::to_string(return_off);
			newnode.instruction = ";WRITEI";
			break;
		case 3:
		case 6:
			return_off = symbol_table->returnOffset(astnode->token);
			tok = "$" + std::to_string(return_off);
			newnode.instruction = ";WRITEF";
			break;
		default:
			tok = astnode->token;
			newnode.instruction = ";WRITES";
			break;

	}
	newnode.oper1 = tok;
	newnode.oper2 = "\0";
	newnode.result = "\0";
	newnode.identity_num = node_num;
	newnode.genSet.push_back(tok);
	node_num ++;
	newnode.successors.push_back(newnode.identity_num + 1);
	IRid_IRNode.insert(pair<int, IRNode>(newnode.identity_num, newnode));

	newObj->InstrSeq.push_back(newnode);
	newObj->result = "\0";
	newObj->type = astnode->token_type;

	return newObj;
}

void convert_ir_to_assembly(IRCode ir_code){
	for (int i = 0 ; i < ir_code.complete_IR_code.size(); i++){
		convert_3AC_code(ir_code.complete_IR_code[i]);
	}
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//WHEN ALL ARE DIRTY
string when_all_dirty(string self, string oper1, string oper2, vector <register_allocation*> reg_vector, set<string> live_out){
	//loop through registers to find out which is not in command
	for(int j = 0; j < reg_vector.size(); j++){
		if ( (reg_vector[j]->temporary_name != self) && (reg_vector[j]->temporary_name != oper1) && (reg_vector[j]->temporary_name != oper2) ){
			//find register in store_map
			for (str_itr = store_map.begin(); str_itr != store_map.end(); ++str_itr) {
				if( str_itr->first == reg_vector[j]->temporary_name){
					cout<<"move "<<reg_vector[j]->register_name<<" "<<str_itr->second<<endl;
					reg_vector[j]->temporary_name = self;
					bool in_liveout = present_in_liveout(self, live_out);
					if(in_liveout){
						reg_vector[j]->dirty_flag = 1;
					}else{
						reg_vector[j]->dirty_flag = 0;
					}
					return reg_vector[j]->temporary_name;
				}
    			}
		}
  	}
}


void check_liveout(vector <register_allocation*> reg_vector, set<string> live_out){
	string to_match = "\0";
	for(int i = 0; i < reg_vector.size(); i++){

		to_match = reg_vector[i]->temporary_name;
		if(live_out.find(to_match) == live_out.end()){

			reg_vector[i]->dirty_flag = 0;
		}
	}
	return;
}


//check if the temporary already exists in any one of the 4 registers
bool already_exists(string operator2, vector <register_allocation*> reg_vector){

  for (int i=0; i< reg_vector.size(); i++){
   if(reg_vector[i]->temporary_name == operator2){
	return true;
    }
  }
  return false;
}

//check if the temporary is in the live out set
bool present_in_liveout(string operator2,set<string> live_out){
  if(live_out.find(operator2) != live_out.end()){
    return true;
  }
  return false;
}////

//setting dirty flag of the register and returing the registers
string set_dirty(string operator2, int set_value ,vector<register_allocation*> reg_vector){
  cout<<"Set dirty function"<<endl;
  for (int i=0; i< reg_vector.size(); i++){
    if(reg_vector[i]->temporary_name == operator2){

      reg_vector[i]->dirty_flag = set_value;
      cout<<"In set dirty function  "<< reg_vector[i]->register_name<<"   dirty:   "<<reg_vector[i]->dirty_flag<<endl;
      return reg_vector[i]->register_name;
    }
  }
}


string does_not_exists(string self, string oper1, string oper2, vector <register_allocation*> reg_vector, set<string> live_out){
  bool in_liveout = present_in_liveout(self, live_out);
  cout<<"Does not exist: live_out: "<<in_liveout<<"Register vector:"<<reg_vector.size()<<endl;
  for(int i = 0; i < reg_vector.size(); i++){
    if(( reg_vector[i]->temporary_name != oper1 ) &&  ( reg_vector[i]->temporary_name != oper2 ) && (reg_vector[i]->dirty_flag == 0)){
      cout<<"register name: inside does not exist "<<reg_vector[i]->register_name<<endl;
      reg_vector[i]->temporary_name = self;
      if(in_liveout){
        reg_vector[i]->dirty_flag = 1;
        return reg_vector[i]->register_name;
      }else{
        reg_vector[i]->dirty_flag = 0;
        return reg_vector[i]->register_name;
      }
    }
  }
  //when they are all dirty what to do ---> it requires value---->how to write store instruction
  //this loop should never reach unless every register has dirty == 1
  cout<<"All dirty"<<endl;
  int all_dirty = 0;
  for(int j = 0; j < reg_vector.size(); j++){
	if(reg_vector[j]->dirty_flag == 1){
		all_dirty = all_dirty + 1;
	}
  }
  if(all_dirty == 4){
	//write a function here
	string new_reg = when_all_dirty(self, oper1, oper2, reg_vector, live_out);
	return new_reg;
  }

}


IRNode return_register(vector <register_allocation*> reg_vector, IRNode n){

	//creating temp_IRNode
	IRNode to_return = n;

  std::string oper1 = n.oper1;
  std::string oper2 = n.oper2;
  std::string result = n.result;

  set<string> live_out = n.LiveOut;
  string new_opr1;
  string new_opr2;
  string new_result;


  //debug it here
  cout<< "Operator1: "<<oper1<<" Operator2: "<<oper2<<" Result "<<result<<endl;
  set<string>::iterator it;
  for(it = live_out.begin(); it != live_out.end(); it ++){
	std::cout<<" "<<*it<<" ";
  }
  cout<<endl;
  //debug ends here

//debug for registers
//	for(int i=0; i< regVect.size(); i++){
//		cout<<"My value is: "<< regVect[i]->register_name<<endl;
//	}

//end here

  //this function creates a hashmap
  if ( ( (isdigit(oper1[0]) == 1) && (result.find("!T") == 0) ) || ( (oper1[0] == '$') && (result.find("!T") == 0) ) ){
	int present = 0;
	//check if result is already in key
	for( str_itr = store_map.begin(); str_itr != store_map.end(); ++str_itr ){
		if(str_itr->first == result){
			present = 1;
			str_itr->second = oper1;
		}
	}
	//if not present
	if(present ==  0){
		store_map.insert(pair<string, string>(result, oper1));
	}


  }

  //debug for store_map
  //cout<<"-------------------MY STORE MAP---------------------------------"<<endl;
  //for (str_itr = store_map.begin(); str_itr != store_map.end(); ++str_itr) {
  //      cout << '\t' << str_itr->first
  //           << '\t' << str_itr->second << '\n';
   // }
   //cout<<"----------------------------------------------------------------"<<endl;
  // ends here

  //checking for dirty_flag
  check_liveout(reg_vector, live_out);

  //if oper1 is a temporary
  if(oper1.find("!T") == 0){
      cout<<"I am in operator 1"<<endl;
      bool exists = already_exists(oper1, reg_vector);
      cout<<"Exists"<<exists<<endl;
      bool in_liveout = present_in_liveout(oper1, live_out);
      cout<<"In Live Out "<<in_liveout<<endl;

      if(exists){
        if(in_liveout){
          new_opr1 = set_dirty(oper1,1,reg_vector);
        }else{
          new_opr1 = set_dirty(oper1,0,reg_vector);
        }
      }else{
        new_opr1 = does_not_exists(oper1, oper2, result, reg_vector, live_out);
      }
      cout<<"New result: (operator 1) "<< new_opr1 << endl;
			to_return.oper1 = new_opr1;
  }
  //for operator 2
  if(oper2.find("!T") == 0){
      cout<<"I am in operator 2"<<endl;
      bool exists = already_exists(oper2, reg_vector);
      cout<<"Exists"<<exists<<endl;
      bool in_liveout = present_in_liveout(oper2, live_out);
      cout<<"In Live Out "<<in_liveout<<endl;

      if(exists){
        if(in_liveout){
          new_opr2 = set_dirty(oper2,1,reg_vector);
        }else{
          new_opr2 = set_dirty(oper2,0,reg_vector);
        }
      }else{
        new_opr2 = does_not_exists(oper2, oper1, result, reg_vector, live_out);
      }
      cout<<"New result: (operator 2) "<< new_opr2 << endl;
			to_return.oper2 = new_opr2;
      //n.result = new_result;
}
  //for result
  if(result.find("!T") == 0){
      cout<<"I am in result  "<<result<<endl;
      bool exists = already_exists(result, reg_vector);
      cout<<"Exists"<<exists<<endl;
      bool in_liveout = present_in_liveout(result, live_out);
      cout<<"In Live Out "<<in_liveout<<endl;

      if(exists){
        if(in_liveout){
          new_result = set_dirty(result,1,reg_vector);
        }else{
          new_result = set_dirty(result,0,reg_vector);
        }
      }else{
        new_result = does_not_exists(result, oper1, oper2, reg_vector, live_out);

      }
      cout<<"New result: (result) "<< new_result << endl;
			to_return.result = new_result;
      //n.result = new_result;
  }


	//cout<<"returned:			"<<"returned.oper1:	"<<to_return.oper1<<"  returned.oper2:		"<<to_return.oper2<<"  returned.result:		"<<to_return.result<<endl;

  return to_return;

}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void convert_3AC_code(CodeObj* currentCodeExpr){

	//debug for registers
	//for(int i=0; i< regVect.size(); i++){
	//	cout<<"My value is: "<< regVect[i]->register_name<<endl;
	//}

	//debug here

	for (int i = 0; i < currentCodeExpr->InstrSeq.size(); i++){

		//write here
		IRNode n = IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num];
		IRNode returned = return_register(regVect, IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num]);
		//my_Debug
		cout<<"n:			"<<"n.oper1:	"<<n.oper1<<"  n.oper2:		"<<n.oper2<<"  n.result:		"<<n.result<<endl;
		cout<<"returned:			"<<"returned.oper1:	"<<returned.oper1<<"  returned.oper2:		"<<returned.oper2<<"  returned.result:		"<<returned.result<<endl;



		//ends here
		// print instr
		if(currentCodeExpr->InstrSeq[i].instruction == ";MULI"){
			std::cout<<"move "<<currentCodeExpr->InstrSeq[i].oper1<<" "<<currentCodeExpr->InstrSeq[i].result<<std::endl;
			std::cout<<"muli"<<" ";

		}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";ADDI"){

			std::cout<<"move "<<currentCodeExpr->InstrSeq[i].oper1<<" "<<currentCodeExpr->InstrSeq[i].result<<std::endl;
			std::cout<<"addi"<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";SUBI"){

			std::cout<<"move "<<currentCodeExpr->InstrSeq[i].oper1<<" "<<currentCodeExpr->InstrSeq[i].result<<std::endl;
			std::cout<<"subi"<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";DIVI"){

			std::cout<<"move "<<currentCodeExpr->InstrSeq[i].oper1<<" "<<currentCodeExpr->InstrSeq[i].result<<std::endl;
			std::cout<<"divi"<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";MULF"){

			std::cout<<"move "<<currentCodeExpr->InstrSeq[i].oper1<<" "<<currentCodeExpr->InstrSeq[i].result<<std::endl;
			std::cout<<"mulr"<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";ADDF"){
			std::cout<<"move "<<currentCodeExpr->InstrSeq[i].oper1<<" "<<currentCodeExpr->InstrSeq[i].result<<std::endl;
			std::cout<<"addr"<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";SUBF"){

			std::cout<<"move "<<currentCodeExpr->InstrSeq[i].oper1<<" "<<currentCodeExpr->InstrSeq[i].result<<std::endl;
			std::cout<<"subr"<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";DIVF"){
			std::cout<<"move "<<currentCodeExpr->InstrSeq[i].oper1<<" "<<currentCodeExpr->InstrSeq[i].result<<std::endl;
			std::cout<<"divr"<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";READI"){ //
			std::cout<<"sys readi"<<" ";
			std::cout<<currentCodeExpr->InstrSeq[i].oper1<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";READF"){ //
			std::cout<<"sys readr"<<" ";
			std::cout<<currentCodeExpr->InstrSeq[i].oper1<<" ";}

		else if(currentCodeExpr->InstrSeq[i].instruction == ";STOREI"){
			std::cout<<"move"<<" ";
			std::cout<<currentCodeExpr->InstrSeq[i].oper1<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";STOREF"){
			std::cout<<"move"<<" ";
			std::cout<<currentCodeExpr->InstrSeq[i].oper1<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";WRITEI"){
			std::cout<<"sys writei"<<" ";
			std::cout<<currentCodeExpr->InstrSeq[i].oper1<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";WRITEF"){
			std::cout<<"sys writer"<<" ";
			std::cout<<currentCodeExpr->InstrSeq[i].oper1<<" ";}
		else if(currentCodeExpr->InstrSeq[i].instruction == ";WRITES"){
			std::cout<<"sys writes"<<" ";
			std::cout<<currentCodeExpr->InstrSeq[i].oper1<<" ";}
		else{
			std::cout<<currentCodeExpr->InstrSeq[i].instruction;
		}


		// print oper2

		std::cout<<currentCodeExpr->InstrSeq[i].oper2<<" ";
		// print result
		std::cout<<currentCodeExpr->InstrSeq[i].result<<std::endl;
		cout<<endl;

	}
}

void print_IRNodeMap(){

	for(int i = 0; i < node_num; i++){
		std::cout<<i<<": "<<IRid_IRNode[i].instruction<<std::endl;
	}
}

//Code from IR.cpp
// print individual STATEMENTS function for debugging
void print_3AC_code(CodeObj* currentCodeExpr, int n){
/*	set<string>::iterator it;
	for (int i = 0; i < currentCodeExpr->InstrSeq.size(); i++){
		std::cout<<"----------------\n";
		std::cout<<currentCodeExpr->InstrSeq[i].instruction<<" ";
		std::cout<<currentCodeExpr->InstrSeq[i].oper1<<" ";
		std::cout<<currentCodeExpr->InstrSeq[i].oper2<<" ";
		std::cout<<currentCodeExpr->InstrSeq[i].result<<" "<<std::endl;
		std::cout<<"node id: "<<currentCodeExpr->InstrSeq[i].identity_num;
		std::cout<<" genset: ";
		for (int j = 0; j < IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].genSet.size(); j++){
			std::cout<<" "<<IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].genSet[j]<<" ";
		}
		std::cout<<" killset: ";
		for (int j = 0; j < IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].killSet.size(); j++){
			std::cout<<" "<<IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].killSet[j]<<" ";
		}
		std::cout<<" successors: ";
		for(int j = 0; j < IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].successors.size(); j++){
			std::cout<<" "<<IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].successors[j]<<" ";
		}
		std::cout<<" predecessors: ";
		for(int j = 0; j < IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].predecessors.size(); j++){
			std::cout<<" "<<IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].predecessors[j]<<" ";
		}
		std::cout<<std::endl;
		std::cout<<"live in: ";
		for(it = IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].LiveIn.begin(); it != IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].LiveIn.end(); it ++){
			std::cout<<" "<<*it<<" ";
		}
		std::cout<<"| live out: ";
		for(it = IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].LiveOut.begin(); it != IRid_IRNode[currentCodeExpr->InstrSeq[i].identity_num].LiveOut.end(); it ++){
			std::cout<<" "<<*it<<" ";
		}
		std::cout<<std::endl;
	}*/
}

void print_IR_code(IRCode ir_code){
	for (int i = 0 ; i < ir_code.complete_IR_code.size(); i++){
		print_3AC_code(ir_code.complete_IR_code[i], i);
	}
}

CodeObj* return_LHS_3AC(std::string Left, CodeObj* Right){
	CodeObj* newObj = new CodeObj();
	IRNode newnode;
	newnode.identity_num = node_num;
	node_num ++;

	long long return_off;
	return_off = symbol_table->returnOffset(Left);
	// assign stuff to IRnode
	newnode.oper1 = Right->result;
	//newnode.oper2 = generateTemp();
	newnode.result = "$" + std::to_string(return_off);
	switch(Right->type){
		case 2:
		case 5:
			newnode.instruction = ";STOREI";
			break;
		case 3:
		case 6:
			newnode.instruction = ";STOREF";
			break;

	}
	newnode.killSet.push_back(newnode.result);
	newnode.genSet.push_back(newnode.oper1);
	newnode.successors.push_back(newnode.identity_num + 1);

	IRid_IRNode.insert(pair<int, IRNode>(newnode.identity_num, newnode));
	// write IRnode to the newObj InstrSeq field
	newObj->InstrSeq.push_back(newnode);
	// fill in type
	newObj->type = Right->type;
	// fill in result field
	return_off = symbol_table->returnOffset(Left);
	newObj->result = "$" + std::to_string(return_off);

	return newObj;
}


CodeObj* return_RHS_3AC(AST* astNode){

	while (astNode != NULL){
		CodeObj* newObj = new CodeObj();
		CodeObj* left_codeObj = return_RHS_3AC(astNode->left);
		CodeObj* right_codeObj = return_RHS_3AC(astNode->right);

		// now generate code for yourself
		if (astNode->token_type == 1){		// arithmetic node

			IRNode newnode;
			// assign operator fields to newnode
			newnode.oper1 = left_codeObj->result;
			newnode.oper2 = right_codeObj->result;
			newnode.identity_num = node_num;
			node_num ++;
			newnode.successors.push_back(newnode.identity_num + 1);

			// assign result location to new temporary
			newnode.result = generateTemp();

			// figure out instruction code
			char oper;
			std::string oper_string = astNode->token;		// +, -, *. /
			if (oper_string == "+"){
				oper = '+';
			}
			else if (oper_string == "-"){
				oper = '-';
			}
			else if (oper_string == "*"){
				oper = '*';
			}
			else{
				oper = '/';
			}
			int type = left_codeObj->type;		// int or float

			switch(type){
				case 2:		// int
				case 5:
					switch(oper){

						case '+': newnode.instruction = ";ADDI";
								  break;
						case '-': newnode.instruction = ";SUBI";
								  break;
						case '*': newnode.instruction = ";MULI";
								  break;
						case '/': newnode.instruction = ";DIVI";
								  break;
					}
					break;
				case 3:		// float
				case 6:
					switch(oper){
						case '+': newnode.instruction = ";ADDF";
								  break;
						case '-': newnode.instruction = ";SUBF";
								  break;
						case '*': newnode.instruction = ";MULF";
								  break;
						case '/': newnode.instruction = ";DIVF";
								  break;
					}
					break;
			}
			newnode.genSet.push_back(newnode.oper1);
			newnode.genSet.push_back(newnode.oper2);
			newnode.killSet.push_back(newnode.result);
			IRid_IRNode.insert(pair<int, IRNode>(newnode.identity_num, newnode));
			// fill in codeObj attributes
			newObj->type = type;
			newObj->result = newnode.result;
			for (int i = 0; i < left_codeObj->InstrSeq.size(); i++){
				newObj->InstrSeq.push_back(left_codeObj->InstrSeq[i]);
			}
			for (int i = 0; i < right_codeObj->InstrSeq.size(); i++){
				newObj->InstrSeq.push_back(right_codeObj->InstrSeq[i]);
			}
			newObj->InstrSeq.push_back(newnode);

		}
		else if (astNode->token_type == 2 || astNode->token_type == 3){	// if it is a literal
			/*
			 * NOT SURE IF THIS NECESSARY *
			 newObj->InstrSeq.push_back(left_codeObj->InstrSeq);
			 newObj->InstrSeq.push_back(right_codeObj->InstrSeq);
			 */
			// creating current 3AC
			IRNode newnode;
			newnode.identity_num = node_num;
			node_num ++;
			newnode.successors.push_back(newnode.identity_num + 1);
			long long offset = symbol_table->returnOffset(astNode->token);
			string strOffset = "$" + std::to_string(offset);
			newnode.oper1 = strOffset;//astNode->token;
			newnode.oper2 = "\0";
			newnode.result = generateTemp();
			newnode.genSet.push_back(newnode.oper1);
			newnode.genSet.push_back(newnode.oper2);
			newnode.killSet.push_back(newnode.result);
			switch(astNode->token_type){
				case 2:	newnode.instruction = ";STOREI";
						break;
				case 3: newnode.instruction = ";STOREF";
						break;
			}

			newObj->InstrSeq.push_back(newnode);
			newObj->type = astNode->token_type;
			newObj->result = newnode.result;
			IRid_IRNode.insert(pair<int, IRNode>(newnode.identity_num, newnode));
		}
		else{
			newObj->result = astNode->token;
			switch(astNode->token_type){
				case 5: newObj->type = 5;
						break;
				case 6: newObj->type = 6;
						break;
			}
		}
		return newObj;
	}
	return NULL;
}

std::string generateTemp(){
	std::string temp;
	temp = "!T";
	temp = temp + std::to_string(tempNum++); // so example temp = "!T10"

	return temp;
}
